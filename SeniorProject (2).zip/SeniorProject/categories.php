<?php include('connection.php');
if(isset($_GET['removeCategory'])){
    $remove_id = $_GET['removeCategory'];
    $response = mysqli_query($con, "DELETE FROM slider WHERE id = $remove_id");
    if($response){?>
    <script>
        alert("Category deleted");
    </script>
    <?php
    }
  };
?>
  
  <!DOCTYPE html>
<html lang="en">

<head>
<div class="tab-pane fade" id="v-pills-categories-tab" role="tabpanel" aria-labelledby="v-pills-categories-tab">
 <form class="row g-3" method="post" enctype="multipart/form-data">
        <h3>Add New Category</h3>
        <div class="col-md-6">
          <label for="inputPassword4" class="form-label">Categories</label>
          <input type="file" class="form-control" id="inputPassword4" name="image" required>
        </div>
        <div class="col-12">
          <button type="submit" class="btn btn-primary" name="category">Add</button>
        </div>
      </form>
                        <th scope="col">ID</th>
                        <th scope="col">Category Name</th>
                        <th scope="col">Category Description</th>
                      </tr>
                    </thead>
                    <tbody>

                    <?php
                while($row = mysqli_fetch_array($result)) {
                    ?>

                      <tr>
                        <th scope="row"><?php echo $row['id'] ?></th>
                        <th scope="row"><?php echo $row['category_name'] ?></th>
                        <th scope="row"><?php echo $row['category_description'] ?></th>
                        <td><a href="adminPage.php?removeCategory=<?php echo $row['id'] ?>" onclick="return confirm('remove the category from categories?')" class="btn btn-danger">Delete</a></td>
                      </tr>
                    </tbody>
                    <?php } ?>
                  </table>

</body>

</html>